import React, { createContext, useState, useContext, useEffect } from 'react';
import { auth, db } from '../utils/firebase';
import { onAuthStateChanged, User, signOut } from 'firebase/auth';
import { doc, getDoc } from 'firebase/firestore';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Alert } from 'react-native';

type AuthContextType = {
  user: User | null;
  userRole: string | null;
  isLoading: boolean;
  logout: () => Promise<void>;
};

const AuthContext = createContext<AuthContextType>({
  user: null,
  userRole: null,
  isLoading: true,
  logout: async () => {},
});

export const useAuth = () => useContext(AuthContext);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [userRole, setUserRole] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      try {
        if (user) {
          // Get user role from Firestore
          const userDoc = await getDoc(doc(db, 'users', user.uid));
          const userData = userDoc.data();
          setUserRole(userData?.role || null);
          
          // Store user data in AsyncStorage
          await AsyncStorage.setItem('user', JSON.stringify({
            uid: user.uid,
            email: user.email,
            role: userData?.role,
          }));
        } else {
          setUserRole(null);
          // Clear stored user data
          await AsyncStorage.removeItem('user');
        }
        
        setUser(user);
      } catch (error) {
        console.error('Error in auth state change:', error);
        Alert.alert('Error', 'There was a problem with authentication. Please try again.');
      } finally {
        setIsLoading(false);
      }
    });

    // Check for stored user data on mount
    const checkStoredUser = async () => {
      try {
        const storedUser = await AsyncStorage.getItem('user');
        if (storedUser && !user) {
          const userData = JSON.parse(storedUser);
          setUserRole(userData.role);
        }
      } catch (error) {
        console.error('Error checking stored user:', error);
      }
    };

    checkStoredUser();

    return () => unsubscribe();
  }, []);

  const logout = async () => {
    try {
      await signOut(auth);
      setUser(null);
      setUserRole(null);
      await AsyncStorage.removeItem('user');
    } catch (error) {
      console.error('Error signing out:', error);
      Alert.alert('Error', 'There was a problem signing out. Please try again.');
    }
  };

  return (
    <AuthContext.Provider value={{ user, userRole, isLoading, logout }}>
      {children}
    </AuthContext.Provider>
  );
} 