import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Dimensions, Platform } from 'react-native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { RootStackParamList } from '../navigation/AppNavigator';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../contexts/AuthContext';

type DashboardScreenProps = {
  navigation: NativeStackNavigationProp<RootStackParamList, 'Dashboard'>;
};

const { width } = Dimensions.get('window');
const isLargeScreen = width > 768;

type Activity = {
  invites: number;
  presentations: number;
  recruits: number;
};

export default function DashboardScreen({ navigation }: DashboardScreenProps) {
  const { logout } = useAuth();
  const [dailyActivity, setDailyActivity] = useState<Activity>({
    invites: 0,
    presentations: 0,
    recruits: 0,
  });

  const [targets] = useState<Activity>({
    invites: 10,
    presentations: 5,
    recruits: 2,
  });

  const handleLogout = async () => {
    try {
      await logout();
      // Navigation will be handled by AuthContext
    } catch (error) {
      console.error('Error logging out:', error);
    }
  };

  const handleLogActivity = (type: keyof Activity) => {
    setDailyActivity(prev => ({
      ...prev,
      [type]: prev[type] + 1
    }));
  };

  const calculateProgress = (current: number, target: number) => {
    return Math.min((current / target) * 100, 100);
  };

  const renderActivityCard = (
    title: string,
    type: keyof Activity,
    icon: string,
    current: number,
    target: number
  ) => {
    const progress = calculateProgress(current, target);

    return (
      <View style={[styles.card, isLargeScreen && styles.largeCard]}>
        <LinearGradient
          colors={['#000000', '#1a1a1a']}
          style={styles.gradientCard}
        >
          <View style={styles.cardHeader}>
            <Ionicons name={icon as any} size={isLargeScreen ? 32 : 24} color="#FFD700" />
            <Text style={styles.cardTitle}>{title}</Text>
          </View>

          <View style={styles.progressContainer}>
            <View style={styles.progressBackground}>
              <View 
                style={[
                  styles.progressBar,
                  { width: `${progress}%` }
                ]}
              />
            </View>
            <Text style={styles.progressText}>
              {current} / {target}
            </Text>
          </View>

          <TouchableOpacity 
            style={styles.button}
            onPress={() => handleLogActivity(type)}
          >
            <LinearGradient
              colors={['#FFD700', '#FDB931']}
              style={styles.buttonGradient}
            >
              <Text style={styles.buttonText}>Log {title}</Text>
            </LinearGradient>
          </TouchableOpacity>
        </LinearGradient>
      </View>
    );
  };

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Daily Progress</Text>
        <TouchableOpacity onPress={handleLogout} style={styles.logoutButton}>
          <Ionicons name="log-out-outline" size={24} color="#FFD700" />
        </TouchableOpacity>
      </View>

      <View style={styles.activityContainer}>
        {renderActivityCard(
          'Invites',
          'invites',
          'people-outline',
          dailyActivity.invites,
          targets.invites
        )}
        {renderActivityCard(
          'Presentations',
          'presentations',
          'easel-outline',
          dailyActivity.presentations,
          targets.presentations
        )}
        {renderActivityCard(
          'Recruits',
          'recruits',
          'person-add-outline',
          dailyActivity.recruits,
          targets.recruits
        )}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 20,
    backgroundColor: '#000000',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#FFD700',
  },
  logoutButton: {
    padding: 8,
  },
  activityContainer: {
    padding: 20,
    gap: 20,
  },
  card: {
    borderRadius: 15,
    overflow: 'hidden',
    ...Platform.select({
      ios: {
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.25,
        shadowRadius: 3.84,
      },
      android: {
        elevation: 5,
      },
    }),
  },
  largeCard: {
    maxWidth: isLargeScreen ? '60%' : '100%',
    alignSelf: 'center',
  },
  gradientCard: {
    padding: 20,
  },
  cardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 15,
  },
  cardTitle: {
    fontSize: isLargeScreen ? 20 : 18,
    fontWeight: 'bold',
    color: '#FFFFFF',
    marginLeft: 10,
  },
  progressContainer: {
    marginBottom: 15,
  },
  progressBackground: {
    height: 10,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 5,
    overflow: 'hidden',
  },
  progressBar: {
    height: '100%',
    backgroundColor: '#FFD700',
    borderRadius: 5,
  },
  progressText: {
    color: '#FFFFFF',
    fontSize: 14,
    marginTop: 5,
    textAlign: 'right',
  },
  button: {
    borderRadius: 10,
    overflow: 'hidden',
  },
  buttonGradient: {
    paddingVertical: 12,
    alignItems: 'center',
  },
  buttonText: {
    color: '#000000',
    fontSize: 16,
    fontWeight: 'bold',
  },
}); 